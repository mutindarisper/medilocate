-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 16, 2021 at 03:35 PM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 7.3.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `major_hospitals`
--

-- --------------------------------------------------------

--
-- Table structure for table `hospital`
--

CREATE TABLE `hospital` (
  `NAME` varchar(37) DEFAULT NULL,
  `COUNTY` varchar(7) DEFAULT NULL,
  `LATITUDE` decimal(8,6) NOT NULL,
  `LONGITUDE` decimal(8,6) DEFAULT NULL,
  `CONTACT` varchar(20) DEFAULT NULL,
  `TYPE` varchar(47) DEFAULT NULL,
  `FACILITY` varchar(40) DEFAULT NULL,
  `CATEGORY` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `hospital`
--

INSERT INTO `hospital` (`NAME`, `COUNTY`, `LATITUDE`, `LONGITUDE`, `CONTACT`, `TYPE`, `FACILITY`, `CATEGORY`) VALUES
('KAREN HEALTH CENTRE', 'NAIROBI', '-1.316911', '36.703618', '+254702222222', 'Ministry of Health', 'Basic Health Centre', 'GENERAL'),
('AAR HOSPITAL SOUTH C', 'NAIROBI', '-1.316530', '36.826665', '+254780888150', 'Private Practice - Private Institution Academic', 'Medical Centre', 'GENERAL'),
('NAIROBI SOUTH B HEALTH CENTRE', 'NAIROBI', '-1.309483', '36.836938', '+254722509165', 'Ministry of Health', 'Basic Health Centre', 'GENERAL'),
('FORCES MEMORIAL HOSPITAL', 'NAIROBI', '-1.309481', '36.803344', '+2540704476662', 'Armed Forces', 'Primary Care Hospital', 'GENERAL'),
('MBAGATHI DISTRICT HOSPITAL', 'NAIROBI', '-1.307925', '36.802242', '+2540202724712', 'Ministry of Health', 'Primary Care Hospital', 'GENERAL'),
('MATER MISERICORDIAE HOSPITAL', 'NAIROBI', '-1.305393', '36.916086', '+254719073000', 'Kenya Episcopal Conference-Catholic Secretariat', 'Secondary Care Hospital', 'GENERAL'),
('NAIROBI WEST HOSPITAL', 'NAIROBI', '-1.304238', '36.825058', '+254722200944', 'Private Practice - Private Institution Academic', 'Primary Care Hospital', 'GENERAL'),
('KENYATTA NATIONAL HOSPITAL', 'NAIROBI', '-1.301440', '36.806804', '+254730643000', 'Ministry of Health', 'National Referral Hospital', 'GENERAL'),
('THE NAIROBI HOSPICE', 'NAIROBI', '-1.301210', '36.805120', '+2540202712361', 'Non-Governmental Organizations', 'Medical Clinic', 'GENERAL'),
('LA FEMME HEALTHCARE CLINIC', 'NAIROBI', '-1.300336', '36.781919', '+254752694365', 'Private Practice - Private Institution Academic', 'Obstetrician-Gynecologist', 'GYNAECOLOGIST'),
('KILIMANI DENTAL CENTRE', 'NAIROBI', '-1.299482', '36.789730', '+254723781369', 'Private Practice-Private Institution Academic', 'DENTAL CLINIC', 'DENTAL'),
('DR. ANGELA MULIRO', 'NAIROBI', '-1.299359', '36.781384', '+254702929901', 'Private Practice', 'Obstetrician-Gynecologist', 'GYNAECOLOGIST'),
('MEDICAL IMAGING SERVICES', 'NAIROBI', '-1.297526', '36.793352', ' +254720449060', 'Private Practice-Private Institution Academic', 'ULTRASOUND SCAN MEDICAL CENTER', 'ULTRASOUND'),
('MASABA HOSPITAL', 'NAIROBI', '-1.296875', '36.780809', '+254714906435', 'Private Practice - Private Institution Academic', 'Medical Centre', 'GENERAL'),
('DR. GM OGWENO', 'NAIROBI', '-1.295994', '36.807990', ' ', 'Private Practice', 'Obstetrician-Gynecologist', 'GYNAECOLOGIST'),
('PLAZA IMAGING SOLUTIONS', 'NAIROBI', '-1.295971', '36.807443', ' +254706622659', 'Private Practice', 'ULTRASOUND SCAN MEDICAL CLINIC', 'ULTRASOUND'),
('VITALRAY HEALTH SOLUTIONS', 'NAIROBI', '-1.295178', '36.806849', '+254202731650', 'PRIVATE PRACTICE', 'ULTRASOUND SCAN MEDICAL CENTER', 'ULTRASOUND'),
('DR. WANGWE', 'NAIROBI', '-1.294733', '36.806607', '+254722771121', 'PRIVATE PRACTICE', 'GYNAECOLOGIST', 'GYNAECOLOGIST'),
('NAIROBI HOSPITAL', 'NAIROBI', '-1.294238', '36.803877', '+254703082000', 'Private Practice - Private Institution Academic', 'Secondary Care Hospital', 'GENERAL'),
('MAKONGENI HEALTH CENTRE', 'NAIROBI', '-1.293940', '36.847540', '+254708761147', 'Ministry of Health', 'Basic Health Centre', 'GENERAL'),
('DR. NGAYU', 'NAIROBI', '-1.291842', '36.788659', '+254733809086', 'PRIVATE PRACTICE', 'GYNAECOLOGIST', 'GYNAECOLOGIST'),
('GALANA DENTAL CENTRE', 'NAIROBI', '-1.291399', '36.782912', ' +254794590159', 'Private Practice-Private Institution Academic', 'DENTAL CLINIC', 'DENTAL'),
('JERICHO HEALTH CENTRE', 'NAIROBI', '-1.291278', '36.871205', '+254715316424', 'Ministry of Health', 'Basic Health Centre', 'GENERAL'),
('NGAIRA AVENUE DISPENSARY', 'NAIROBI', '-1.288940', '36.822510', '+254722568294', 'Ministry of Health', 'Basic Health Centre', 'GENERAL'),
('BAHATI HEALTH CENTRE', 'NAIROBI', '-1.288905', '36.863007', '+254020791035', 'Ministry of Health', 'Basic Health Centre', 'GENERAL'),
('THE NAIROBI DENTAL SUITE LIMITED', 'NAIROBI', '-1.288666', '36.786564', '+254706100995', 'Private Practice-Private Institution Academic', 'EMERGENCY DENTAL SERVICE', 'DENTAL'),
('DR K. Onyango', 'NAIROBI', '-1.288002', '36.825814', ' +254722 519388', 'PRIVATE PRACTICE', 'GYNAECOLOGIST', 'GYNAECOLOGIST'),
('MOLARS DENTAL CLINIC', 'NAIROBI', '-1.287720', '36.825912', '+254751856900', 'PRIVATE PRACTICE', 'DENTAL CLINIC', 'DENTAL'),
('METROPOLITAN HOSPITAL', 'NAIROBI', '-1.287674', '36.875128', '+254722207665', 'Private Practice - Private Institution Academic', 'Primary Care Hospital', 'GENERAL'),
('KAWANGWARE HEALTH CENTRE', 'NAIROBI', '-1.287561', '36.749176', '+254721459166', 'Ministry of Health', 'Basic Health Centre', 'GENERAL'),
('TUMAINI MEDICAL LAB CENTER', 'NAIROBI', '-1.286315', '36.825772', '+254202731650', 'PRIVATE PRACTICE', 'ULTRASOUND SCAN MEDICAL CENTER', 'ULTRASOUND'),
('NAIROBI DENTAL POLYCLINICS', 'NAIROBI', '-1.286157', '36.825058', '+254202113111', 'PRIVATE PRACTICE', 'DENTAL CLINIC', 'DENTAL'),
('APTC  EMBAKASI HEALTH CENTRE', 'NAIROBI', '-1.285483', '36.885312', '+254722671358', 'Armed Forces', 'Basic Health Centre', 'GENERAL'),
('CRESENT MEDICAL AID KENYA', 'NAIROBI', '-1.282989', '36.820748', '+2540202222575', 'Non-Governmental Organizations', 'Medical Clinic', 'GENERAL'),
('EASTLEIGH ULTRASOUND SERVICES', 'NAIROBI', '-1.273993', '36.849625', ' ', 'Private Practice', 'ULTRASOUND SCAN MEDICAL CENTER', 'ULTRASOUND'),
('Nairobi Gynae Centre', 'NAIROBI', '-1.273171', '36.801186', ' +254722 687249', 'PRIVATE PRACTICE', 'GYNAECOLOGIST', 'GYNAECOLOGIST'),
('NGARA HEALTH CENTRE', 'NAIROBI', '-1.270770', '36.830460', '+2540203500279', 'Ministry of Health', 'Basic Health Centre', 'GENERAL'),
('UNIVERSITY OF NAIROBI HEALTH SERVICES', 'NAIROBI', '-1.270000', '36.810000', '+2540202724895', 'The University of Nairobi', 'Medical Clinic', 'GENERAL'),
('GURU NANAK HOSPITAL', 'NAIROBI', '-1.267480', '36.831229', '+254722533650', 'Private Practice - Private Institution Academic', 'Primary Care Hospital', 'GENERAL'),
('KANGEMI HEALTH CENTRE', 'NAIROBI', '-1.267318', '36.749339', '+254702733126', 'Ministry of Health', 'Basic Health Centre', 'GENERAL'),
('M P SHAH HOSPITAL', 'NAIROBI', '-1.262455', '36.812221', '+2540204291100', 'Private Practice - Private Institution Academic', 'Primary Care Hospital', 'GENERAL'),
('WESTLANDS HEALTH CENTRE', 'NAIROBI', '-1.260875', '36.799596', '+245705569267', 'Non-Governmental Organizations', 'Medical Center', 'GENERAL'),
('MATHARI MENTAL HOSPITAL', 'NAIROBI', '-1.259489', '36.844302', '+2540202337694', 'Ministry of Health', 'Specialized & Tertiary Referral hospital', 'GENERAL'),
('AGA KHAN HOSPITAL', 'NAIROBI', '-1.259263', '36.822479', '+2540203662000', 'Private Practice - Private Institution Academic', 'Secondary Care Hospital', 'GENERAL'),
('GETRUDES GARDENS CHILDREN\'S HOSPITAL', 'NAIROBI', '-1.256149', '36.831785', '+2540207206000', 'Private Practice - Clinical Officer', 'Primary Care Hospital', 'GENERAL'),
('MATHARE NORTH HEALTH CENTRE', 'NAIROBI', '-1.255790', '36.865669', '+254718737659', 'Ministry of Health', 'Basic Health Centre', 'GENERAL'),
('DANDORA HEALTH CENTRE', 'NAIROBI', '-1.247519', '36.903410', '+254020792081', 'Ministry of Health', 'Basic Health Centre', 'GENERAL'),
('BABA DOGO HEALTH CENTRE', 'NAIROBI', '-1.247024', '36.885384', '+254020802120', 'Ministry of Health', 'Basic Health Centre', 'GENERAL'),
('RAINBOW SMILES DENTAL CLINIC', 'NAIROBI', '-1.235353', '36.811139', '+254757751100', 'PRIVATE PRACTICE', 'DENTAL CLINIC', 'GENERAL'),
('DENTAL CAPITAL NAIROBI', 'NAIROBI', '-1.232574', '36.873749', '+254710303050', 'Private Practice-Private Institution Academic', 'DENTAL CLINIC', 'DENTAL'),
('LITTLE SISTERS OF ST FRANCIS', 'NAIROBI', '-1.225777', '36.916131', '+254736562277', 'Kenya Episcopal Conference-Catholic Secretariat', 'Primary Care Hospital', 'GENERAL'),
('DENSE SMILE DENTAL CLINIC', 'NAIROBI', '-1.219614', '36.889900', '+254714518185', 'Private Practice-Private Institution Academic', 'DENTAL CLINIC', 'DENTAL');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `hospital`
--
ALTER TABLE `hospital`
  ADD PRIMARY KEY (`LATITUDE`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
